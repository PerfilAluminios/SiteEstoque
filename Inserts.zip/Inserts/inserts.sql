insert into estoque values (1,20,2017/11/24,1);
insert into estoque values (2,35,2017/09/14,6);
insert into estoque values (3,10,2017/04/09,3);
insert into estoque values (4,40,2017/10/04,2);
insert into estoque values (5,3,2017/12/25,7);
insert into estoque values (6,18,2017/07/19,8);
insert into estoque values (7,11,2017/06/05,5);
insert into estoque values (8,12,2017/01/03,2);
insert into estoque values (9,8,2017/08/31,9);
insert into estoque values (10,10,2017/11/02,4);



insert into produto values (1,"tela Mosqueteira","R$8,49","1m","Prata");
insert into produto values (2,"Ferragens","R$9,00","0,5m","Cinza");
insert into produto values (3,"Mancal Trilho","R$14,70","2m","Branco");
insert into produto values (4,"Perfil Hibrido De Aluminio","R$10,50","1,6m","Preto");
insert into produto values (5,"Tubo de Aluminio","R$40,00","2,5m","Prata");
insert into produto values (6,"Perfil Alpex","R$9,90","2m","Preto");
insert into produto values (7,"Perfil Aluminio tipo J","R$22,50","1m","Cinza");
insert into produto values (8,"Perfil de Aluminio Virgula","R$75,00","0,5m","Amarelo");
insert into produto values (9,"Cobertura Aluminio","R$699,00","3m","Branco");
insert into produto values (10,"Capa de Fechamento Frontal","R$1,65","5m","Prata");



insert into fornecedor_has_protudo values (2,3);
insert into fornecedor_has_protudo values (3,1);
insert into fornecedor_has_protudo values (1,4);
insert into fornecedor_has_protudo values (6,8);
insert into fornecedor_has_protudo values (4,5);
insert into fornecedor_has_protudo values (8,10);
insert into fornecedor_has_protudo values (5,7);
insert into fornecedor_has_protudo values (10,9);
insert into fornecedor_has_protudo values (9,2);
insert into fornecedor_has_protudo values (7,6);



insert into fornecedor values (1,"Empresa1","Jos� Carlos","12.945.678/0009-42","452.987.123-02","jose@gamil.com","3831-8541");

insert into fornecedor values (2,"Empresa2","Renato","42.526.125/3003-12","364.416.454-01","renato@gamil.com","4654-1652");

insert into fornecedor values (3,"Empresa3","Gabriela","54.256.785/0012-23","245.126.311-09","gabriela@gamil.com","7812-5431");

insert into fornecedor values (4,"Empresa4","Antonio","27.522.654/1234-15","425.253.065-32","antonio@gamil.com","3831-4758");

insert into fornecedor values (5,"Empresa5","Lucas","15.845.412/4321-35","346.245.326-10","lucas@gamil.com","3138-2445");

insert into fornecedor values (6,"Empresa6","Daniel","37.161.431/56789-11","855.365.455-06","daniel@gamil.com","6542-6516");

insert into fornecedor values (7,"Empresa7","Caio","45.346.742/98765-16","574.544.486-15","caio@gamil.com","4528-4786");

insert into fornecedor values (8,"Empresa8","Rodrigo","78.441.124/1112-45","846.784.844-09","rodrigo@gamil.com","3831-8556");

insert into fornecedor values (9,"Empresa9","Luis","96.444.431/1314-29","687.871.678-04","luis@gamil.com","4785-6365");

insert into fornecedor values (10,"Empresa10","Allison","21.635.425/1413-08","987.357.321-04","allison@gamil.com","3361-1999");
